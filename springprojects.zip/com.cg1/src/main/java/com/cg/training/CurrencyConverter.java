package com.cg.training;

public interface CurrencyConverter {
		
	public double dollarsToRupees(double dollars); 

}
