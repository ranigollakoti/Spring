package com.cg.training;

public class ExchangeServiceImpl implements ExchangeService {

	
	public ExchangeServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	private double exchangeRate;
	
	public ExchangeServiceImpl(double exchangeRate) {
		super();
		System.out.println("ExchangeServiceImpl()");
		this.exchangeRate = exchangeRate;
	}

	public double getExchangeRate() {
		System.out.println("getExchangeRate()");
		return exchangeRate;
	}

}
