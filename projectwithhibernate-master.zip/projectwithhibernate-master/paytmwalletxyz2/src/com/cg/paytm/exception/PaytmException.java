package com.cg.paytm.exception;

public class PaytmException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaytmException() {
		super();
		
	}

	public PaytmException(String arg0) {
		super(arg0);
	
	}

}
